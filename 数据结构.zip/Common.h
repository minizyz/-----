const int OK=1;
const int ERROR=0;
typedef int Status;