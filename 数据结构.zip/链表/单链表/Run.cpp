// #include<iostream>
#include"Main.h"
using namespace std;
LinkList Link;
int main(){
    CreateList(&Link,10);

} */